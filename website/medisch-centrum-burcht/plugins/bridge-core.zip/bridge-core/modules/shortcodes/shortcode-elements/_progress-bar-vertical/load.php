<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_progress-bar-vertical/progress-bar-vertical.php';
