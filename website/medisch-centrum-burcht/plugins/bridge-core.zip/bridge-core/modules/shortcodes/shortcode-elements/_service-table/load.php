<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_service-table/service-table.php';
