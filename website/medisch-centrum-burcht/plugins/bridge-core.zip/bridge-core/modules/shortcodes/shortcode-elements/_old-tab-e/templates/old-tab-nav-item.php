<li>
    <a href="#<?php echo esc_attr( $tab_id ); ?>"><?php echo esc_html($title); ?></a>
</li>