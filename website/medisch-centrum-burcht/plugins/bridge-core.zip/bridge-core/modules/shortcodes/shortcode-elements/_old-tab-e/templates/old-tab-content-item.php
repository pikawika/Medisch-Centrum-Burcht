<div id="<?php echo esc_attr( $tab_id ); ?>" class="tab-content">
    <?php echo bridge_qode_get_module_part( $content ); ?>
</div>