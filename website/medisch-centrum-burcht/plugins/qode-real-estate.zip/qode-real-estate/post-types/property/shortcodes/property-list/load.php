<?php

require_once 'property-list.php';
require_once 'helper-functions.php';