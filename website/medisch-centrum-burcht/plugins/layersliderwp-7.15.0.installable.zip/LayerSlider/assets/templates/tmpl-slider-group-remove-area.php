<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<div id="ls-group-remove-area">
	<div class="ls-drop-area">
		<?= lsGetSVGIcon('sign-out-alt', 'duotone') ?>
		<ls-p data-text="<?= __("Drag projects here to move them from this group to the main grid.", 'LayerSlider') ?>" data-drop-text="<?= __('Release project to move it from this group to the main grid.', 'LayerSlider') ?>"></ls-p>
	</div>
</div>