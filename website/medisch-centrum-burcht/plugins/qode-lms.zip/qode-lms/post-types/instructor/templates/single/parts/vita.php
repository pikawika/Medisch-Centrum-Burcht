<?php if ( ! empty( $vita ) ) { ?>
	<p class="qode-vita">
		<?php echo esc_html( $vita ); ?>
	</p>
<?php } ?>